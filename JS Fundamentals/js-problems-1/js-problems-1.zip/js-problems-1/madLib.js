let madLib = (verb, adjective, noun) => {
    return "We shall " + verb.toUpperCase() + " the " + adjective.toUpperCase() + " " + noun.toUpperCase() + "."
}

console.log(madLib('make', 'best', 'guac'));